## Patch for ESP-IDF VSCode plugin to run in the WSL2 but with local python

Direct to this directory,and run `pip install -r requirements.txt`